import java.io.Serializable;

public abstract class Joueur implements Serializable {

    /** Jeton associe au Joueur*/
    private Jeton jetons;

    /** Nombre de victoires */
    private int victoires;

    /**
     * Constructeur de joueur
     * @param j jeton a associer au joueur
     */
    public Joueur(Jeton j){
        this.jetons = j;
        this.victoires = 0;
    }

    /**
     * Methode get du jeton associe au joueur
     * @return jeton associe au joueur
     */
    public Jeton getJeton() { return jetons; }

    /**
     * Methode permettant d'incrementer le nombre de victoire
     */
    public void augmenterVictoire(){
        this.victoires ++;
    }

    /**
     * Methode get de l'attribut victoire
     * @return l'attribut victoire
     */
    public int getVictoire(){
        return this.victoires;
    }

    /**
     * Methode toString de la classe abstraite Joueur
     * @return une chaine de caractere contenant un affichage de Joueur
     */
    public abstract String toString();

}
