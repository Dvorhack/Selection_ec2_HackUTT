import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Jeu {

    /** Grille du Jeu courant */
    private Grille grille;

    /** Nombre de parties faites */
    private static int nbparties = 0;

    /** Tableau de Joueurs */
    Joueur[] joueurs;


    /**
     * Constructeur de Puissance 4
     * @param j tableau de Joueurs
     */
    public Jeu(Joueur[] j){
        this.joueurs = j;
        this.grille = new Grille();
    }

    /**
     * Methode bonus permettant de donner un conseil humoristique au joueur en plein partie
     */
    public void donnerUnConseil(){
        try{
            BufferedReader fr = new BufferedReader(new FileReader("conseils.txt"));
            int i = (int) (Math.random()*4)+1; //On prend ici l'indice d'un nom au hasard dans le fichier de noms
            String s = "";
            for(int k = 0; k<=i; k++){
                s = fr.readLine();
            }
            System.out.println(s);
        } catch (FileNotFoundException e){
            System.out.println("[+] Fichier contenant les noms introuvable.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methode permettant aux Joueurs de prendre un choix
     * @param i indice du joueur dans le tableau de Joueur devant prendre un choix
     * @return numero du choix correspondant
     */
    public int choix(int i){
        int choix;
        if(this.joueurs[i] instanceof VraiJoueur){ // Si le Joueur est un VraiJoueur, on lui demande ce qu'il veut faire
            VraiJoueur j = (VraiJoueur) this.joueurs[i];
            System.out.println("\n[+] Tour de "+j.getNom());
            choix = j.demanderChoix();
        } else { // Si le Joueur est un Bot, on continue de jouer
            choix = 1;
        }
        return choix;
    }

    /**
     * Methode permettant de voir si la partie est gagnee et d'annoncer le vainqueur si c'est le cas
     * @return true si la partie est gagnee
     */
    public boolean checkerVictoire(){
        return this.grille.victoire();
    }

    /**
     * Methode permettant a un Joueur de jouer son tour
     * @param i indice du joueur qui joue dans le tableau de joueurs
     * @return 1 si on joue, 2 si la partie a ete chargee, 3 si la partie a ete sauvegardee, 10 si la partie est gagnee
     */
    public int jouer(int i) throws InterruptedException {
        int c = this.choix(i); // On commence par demander ce que l'on fait

        while (c == 3) {
            this.grille.sauvegarder();
            System.out.println("[+] Partie sauvegardee ");
            Thread.sleep(1000); // On attend 1 seconde pour marquer une pause (cela est purement esthetique)
            c = this.choix(i);
        }
        if (c == 2) { //Restauration de la sauvegarde
            this.grille = Grille.restaurer();
            Thread.sleep(1000); // On attend 1 seconde pour marquer une pause (cela est purement esthetique)
            c = 1; //Apres le chargement, on lance la partie
        } else if(c == 0){ //Annulation du dernier coup
            this.grille.restaurerHistorique();
            System.out.println("[+] C'est encore à ton tour");
            Thread.sleep(1000);
        } else if(c==5){
            for(int j = 0; j<50; j++){ //On passe beaucoup de lignes pour "changer de fenetre"
                System.out.println("\n");
            }

            System.out.println("[+] Vous avez demandé un conseil au grand sage du Puissance 4 !...");
            System.out.println("[+] Voici son conseil... : ");
            Thread.sleep(1000);
            this.donnerUnConseil();
            Thread.sleep(3000);
        } else if(c == 1) { // On lance/continue la partie
            int colonne;
            if(this.joueurs[i] instanceof VraiJoueur){ //Dans le cas où le joueur est un VraiJoueur, on lui demande quelle Colonne celui-ci veut choisir
                VraiJoueur j = (VraiJoueur) this.joueurs[i];
                colonne = j.demanderColonne();
                for(int k = 0; k<50; k++){ //On passe beaucoup de lignes pour "changer de fenetre"
                    System.out.println("\n");
                }
            } else { //Dans le cas où le Joueur est un bot, on prend un nombre random pour la Colonne
                Bot b = (Bot) this.joueurs[i];
                System.out.println("[+] C'est le tour de "+b.getNom() + "!");
                Thread.sleep(1000);
                colonne = (int) (Math.random()*(Grille.largeur+1)-1);
                System.out.println(b.toString()+ " joue en " + colonne);
            }
            this.grille.inserer(joueurs[i], colonne);
            if(this.checkerVictoire()){ //Après insertion, on regarde si la partie est gagnee
                System.out.println("[+] Nous avons un gagnant !");
                Thread.sleep(1000);
                this.joueurs[i].augmenterVictoire();
                String nom;
                if(this.joueurs[i] instanceof VraiJoueur){
                    VraiJoueur j = (VraiJoueur) joueurs[i];
                    nom = j.getNom();
                } else {
                    Bot b = (Bot) joueurs[i];
                    nom = "BOT " + b.getNom();
                }
                System.out.println("[+] Bravo '" + nom + "'. Tu as remporté la victoire !"); //Annonce du gagnant
                System.out.println("[+] Cela te fait au total "+ this.joueurs[i].getVictoire() + " victoire(s) !\n");
                c = 10;
                Thread.sleep(3000);
            }
            System.out.println(this.grille.toString());
            System.out.println(this.grille.affichageRemplissageTrie());
            Thread.sleep(1000);
        }
        return c;
    }



}
