import java.io.*;

public class Bot extends Joueur{

    /** Nom du bot */
    private String nom;

    /**
     * Constructeur de Bot.
     * Le nom du bot est choisi au hasard dans le fichier 'names.txt' present à la racine du projet.
     * @param j jeton à associer au bot
     */
    public Bot(Jeton j){
        super(j);
        try{ // On intercepte les exceptions en interne pour ne pas stopper l'execution dans le main
            BufferedReader fr = new BufferedReader(new FileReader("names.txt"));
            int i = (int) (Math.random()*15)+1; //On prend ici l'indice d'un nom au hasard dans le fichier de noms
            String s = "";
            for(int k = 0; k<=i; k++){
                s = fr.readLine();
            }
            this.nom = s;
        } catch (FileNotFoundException e){
            System.out.println("[+] Fichier contenant les noms introuvable");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methode get du Nom du Bot
     * @return nom du bot
     */
    public String getNom() { return nom; }

    /**
     * Methode toString de la classe Bot
     * @return l'Affichage du Bot
     */
    public String toString() {
        String res = "Bot : " + this.getNom();
        return res;
    }
}
