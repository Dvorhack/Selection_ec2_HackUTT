import java.io.Serializable;
import java.util.*;

public class Colonne implements Serializable, Comparable<Colonne> {

    /** Nombre de jetons dans la colonne */
    private int taille;

    /** Emplacement dans Grille */
    private int label;

    /** Liste de jetons */
    private ArrayList<Jeton> liste;

    /** Contructeur de Colonne
     * @param l label de la Colonne
     */
    public Colonne(int l){
        this.taille = 0;
        this.liste = new ArrayList<Jeton>();
        this.label = l;
    }

    /**
     * Contructeur copie de la colonne en parametre
     * @param c Colonne a copier
     */
    public Colonne(Colonne c){
        this.label = c.label;
        this.liste = c.liste;
        this.taille = c.taille;
    }

    /**
     * Métode get de l'attribut taille.
     * @return la taille de l'objet Colonne
     */
    public int getTaille(){ return this.taille; }

    /**
     * Methode get de l'attribut label.
     * @return le label de l'objet Colonne dans la Grille
     */
    public int getLabel() { return label; }

    /**
     * Methode d'ajout d'un jeton dans la Colonne.
     * @param jeton jeton à ajouter dans la Colonne
     */
    public void add(Jeton jeton){
        this.liste.add(jeton);
        this.taille++;
    }

    /**
     * Methode de supression du dernier Jeton de la Colonne
     * On s'en sert pour gerer l'historique de Grille a chaque tour
     */
    public void removeLast(){
        this.liste.remove(this.liste.size()-1);
    }

    /**
     * Methode de conversion de la colonne en tableau de Jeton.
     * Le tableau est rempli en reverse par rapport à la colonne pour faciliter l'affichage dans la methode toString de Grille.
     * @return tableau de jetons
     */
    public Jeton[] tabVal(int hauteur){
        Jeton[] res = new Jeton[hauteur];
        int k = 0;
        for(int i = hauteur-1; i>=0; i--){
            if(i>=this.liste.size()) res[k] = null;
            else res[k] = this.liste.get(i);
            k++;
        }
        return res;
    }

    /**
     * Methode de conversion de la colonne en tableau de Jeton.
     * @return tableau de jetons
     */
    public Jeton[] tabValDansOrdre(int hauteur){
        Jeton[] res = new Jeton[hauteur];
        int k = 0;
        for(int i = 0; i<hauteur; i++){
            if(i>=this.liste.size()) res[k] = null;
            else res[k] = this.liste.get(i);
            k++;
        }
        return res;
    }

    /**
     * Methode compareTo implementee de Comparable
     * Cette methode sert a comparer les Colonnes entre elles dans Grille
     * @param colonne Colonne avec laquelle on veut comparer l'objet Colonne
     * @return la taille de la Colonne (element qui sert de comparaison entre les Colonnes)
     */
    public int compareTo(Colonne colonne) {
        return colonne.getTaille() - this.getTaille();
    }


}
