public class TestColonne {

    public static void main(String[] args) {
        try{
            Jeton j = new Jeton(3);
            Jeton j1 = new Jeton(4);

            //Test de création d'un Colonne
            Colonne c = new Colonne(1);
            System.out.println("\nTest 1 : ok");

            //Test d'insertion de Jeton dans une Colonne + methode de conversion en tableau (doit afficher 3)
            c.add(j);
            c.add(j1);
            System.out.println("\nTest 2 : " + c.tabVal(1)[0].getValeur());

            //Test de la methode de conversion en tableau dans l'ordre (doit afficher 3)
            c.add(j1);
            System.out.println("\nTest 3 : " + c.tabValDansOrdre(1)[0].getValeur());

            //Test methode de suppression de colonnes (doit afficher 4)
            Colonne c1 = new Colonne(2);
            c.add(j);
            c.add(j1);
            c.add(j1);
            c.add(j);
            c.removeLast();
            System.out.println("\nTest 4 : " + c.tabVal(3)[0].getValeur());


        } catch (JetonException e){
            System.out.println(e);
            System.exit(-1); // Sortie du programme
        }




    }


}
