import java.io.Serializable;

public class Jeton implements Serializable{

    /** Valeur du jeton (1 ou 2) */
    private int valeur;

    /**
     * Constructeur de jeton
     * @param val valeur à associer au jeton comprise entre 1 et 2 inclus
     */
    public Jeton(int val) throws JetonException{
        if(val >= 0)
            this.valeur = val;
        else
            throw new JetonException("Valeur associée au Jeton inférieure à 0 !");
    }

    /**
     * Methode get de Jeton
     * @return la valeur associe au jeton
     */
    public int getValeur() { return valeur; }

    /**
     * Methode equals de Jeton
     * @param j Jeton a comparer
     * @return true si les deux Jetons portent la meme valeur
     */
    public boolean equals(Jeton j){
        if(j == null) return false;
        else return (this.valeur == j.getValeur());
    }


}
