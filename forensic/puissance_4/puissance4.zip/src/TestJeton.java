import java.sql.SQLOutput;

public class TestJeton {

    public static void main(String[] args) {

        /* Test de création d'un Jeton */
        System.out.println("\nTest 1 : ");
        try{
            Jeton j = new Jeton(2);
            System.out.println("valeur du jeton : " + j.getValeur());
        } catch (JetonException e){
            System.out.println(e);
            System.exit(-1); // Sortie du programme
        }

        /* Test de la méthode equals */
        System.out.println("\nTest 2 : ");
        try{
            Jeton j = new Jeton(2);
            Jeton j1 = new Jeton(2);
            Jeton j2 = new Jeton(3);
            if(j.equals(j1) && !j.equals(j2))
                System.out.println("ok");
            else
                System.out.println("equals cassé");
        } catch(JetonException e){
            System.out.println(e);
            System.exit(-1); // Sortie du programme
        }

        /* Test de création d'un Jeton avec une valeur inferieure à zero */
        System.out.println("\nTest 3 : ");
        try{
            Jeton j = new Jeton(-1);
            System.out.println("valeur du jeton : " + j.getValeur());
        } catch (JetonException e){
            System.out.println(e);
            System.exit(-1); // Sortie du programme
        }
    }
}
