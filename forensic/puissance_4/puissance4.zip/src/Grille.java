//balayage diag et droit pour victoire

import java.io.*;
import java.util.*;

public class Grille implements Serializable {

    /** Hauteur de la Grille, correspond au nombre d'element de la colonne la plus grande de la grille */
    private int hauteur;

    /** Largeur de la grille, correspondant au nombre de jeton intercalable sur une ligne, comprise entre 3 et 10 pour le respect des regles */
    public static int largeur = 10;

    /** ArrayList contenant les colonnes de la grille */
    private ArrayList<Colonne> listeColonnes;

    /** Liste FIFO contenant dans l'ordre les numeros de Colonne ayant recu une insertion */
    private Pile pileHistorique;

    /**
     * Constructeur de Grille
     */
    public Grille() {
        this.hauteur = 0;
        this.listeColonnes = new ArrayList<Colonne>(largeur);
        for (int i = 0; i < largeur; i++) {
            this.listeColonnes.add(new Colonne(i));
        }
        this.pileHistorique = new Pile();
    }

    /**
     * Methode get de l'attribut hauteur
     * @return valeur de l'attribut hauteur
     */
    public int getHauteur() {
        return hauteur;
    }

    /**
     * Methode permettant de raffraichir la hauteur de la grille
     * @return hauteur de la grille rechargee
     */
    public int tailleReload() {
        int max = this.hauteur;
        for (int i = 0; i < largeur; i++) {
            if (this.listeColonnes.get(i).getTaille() > max) {
                max = this.listeColonnes.get(i).getTaille();
            }
        }
        return max;
    }

    /**
     * Methode de restauration de l'historique (retour en arriere) de la Grille
     */
    public void restaurerHistorique(){
        try{ // On surround cette ligne par un try car si aucune insertion ne peut etre annulée, on ne veut pas stopper l'execution du main
            this.listeColonnes.get(this.pileHistorique.depiler()).removeLast();
        } catch (NoSuchElementException e){
            System.out.println("[+] Il n'y a pas d'insertion à annuler !");
        }

    }

    /**
     * Methode d'insertion du Jeton d'un Joueur dans la grille
     * @param j Joueur dont le Jeton doit etre insere
     * @param colonne Colonne dans laquelle le Jeton doit etre insere
     */
    public void inserer(Joueur j, int colonne) {
        this.pileHistorique.empiler(colonne); //On sauvegarde dans le fichier tmp pour pouvoir acceder a l'historique
        this.listeColonnes.get(colonne).add(j.getJeton());
        this.hauteur = this.tailleReload();
    }

    /**
     * Methode servant a sauvegarder la Grille (ainsi que les objets associés) dans "save.ser"
     */
    public void sauvegarder() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("save.ser"));
            out.writeObject(this);
            out.close();
            System.out.println("[+] Grille sauvegardée avec succès !\n");
        } catch (FileNotFoundException e){
            System.out.println("Erreur d'ouverture du fichier : \n" + e);
        } catch (IOException e) {
            System.out.println("Erreur d'écriture de la sauvegarde : \n" + e);
        }
    }

    /**
     * Methode servant a recuperer la Grille serialisee dans 'save.ser'
     * @return la Grille recuperee ou null si aucune grille n'a pu etre recupere
     */
    public static Grille restaurer(){
        Grille g = null;
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("save.ser"));
            g = (Grille) in.readObject();
            in.close();
            System.out.println("[+] Grille chargée avec succès !\n");
        } catch (FileNotFoundException e){
            System.out.println("Erreur d'ouverture du fichier : \n" + e);
        } catch (IOException e) {
            System.out.println("Erreur de récupération de la sauvegarde : \n" + e);
        } catch (ClassNotFoundException e) {
            System.out.println("Pas de Grille trouvée dans 'save.ser' : \n"+ e);
        }
        return g;
    }

    public String affichageRemplissageTrie(){
        ArrayList<Colonne> l = new ArrayList<>(this.listeColonnes.size()); //On remplit la liste de cette manière pour pas que cette liste dépende de l'attribut listeColonne
        for(int i = 0; i<this.listeColonnes.size(); i++){
            l.add(new Colonne(this.listeColonnes.get(i)));
        }

        Collections.sort(l);
        double moy = 0;
        int nb = 0;
        StringBuilder res = new StringBuilder();
        res.append("Colonnes triées par remplissage  : ");
        for(int i = 0; i<largeur; i++){
            nb = l.get(i).getTaille();
            res.append(l.get(i).getLabel()).append("(").append(nb).append("), ");
            moy += l.get(i).getTaille();
        }
        moy /= largeur;
        res.append("\nMoyenne de remplissage (en case) : ").append(moy);
        return res.toString();
    }

    /**
     * Methode permettant de detecter un alignement vertical dans la Grille
     * @return true si quatre Jetons sont alignes verticalement dans la grille
     */
    public boolean quatreVertical(){
        boolean quatre = false;
        int compteur; //compteur de Jetons alignes
        Jeton old; //Jeton que l'on compte
        boucle: //label servant a stopper l'iteration si quatre memes Jetons sont alignes
        for(int i = 0; i<largeur; i++){ // Boucle sur les colonnes
            compteur = 1;
            old = null;
            for(int j = 0; j<hauteur; j++){ // Boucle sur les elements des colonnes
                try{
                    if(!this.listeColonnes.get(i).tabVal(this.getHauteur())[j].equals(old)){ //Si le Jeton vise est different du old...
                        old = this.listeColonnes.get(i).tabVal(this.getHauteur())[j]; //on assigne a old le Jeton vise et on reinitialise le compteur
                        compteur = 1;
                    } else { //sinon on incremente le compteur
                        compteur ++;
                    }
                } catch (ArrayIndexOutOfBoundsException | NullPointerException e){ //Exception dans le cas où l'element vise ne contient rien ou est nul
                    compteur = 1; //on reinitialise le compteur et old
                    old = null;
                }
                if(compteur == 4){ //Si le compteur vaut 4, il y a victoire. On sort de la boucle
                    quatre = true;
                    break boucle;
                }
            }
        }
        return quatre;
    }

    /**
     * Methode permettant de detecter un alignement horizontal dans la Grille
     * @return true si quatre Jetons sont alignes horizontalement dans la grille
     */
    public boolean quatreHorizontal(){
        boolean quatre = false;
        int compteur; //compteur de Jetons alignes
        Jeton old; //Jeton que l'on compte
        boucle: //label servant a stopper l'iteration si quatre memes Jetons sont alignes
        for(int i = 0; i<hauteur; i++){ // Boucle sur les lignes
            compteur = 1;
            old = null;
            for(int j = 0; j<largeur; j++){ // Boucle sur les Colonnes
                try{
                    if(!this.listeColonnes.get(j).tabVal(this.getHauteur())[i].equals(old)){ //Si le Jeton vise est different du old...
                        old = this.listeColonnes.get(j).tabVal(this.getHauteur())[i]; //on assigne a old le Jeton vise et on reinitialise le compteur
                        compteur = 1;
                    } else { //sinon on incremente le compteur
                        compteur ++;
                    }
                } catch (ArrayIndexOutOfBoundsException | NullPointerException e){ //Exception dans le cas où l'element vise ne contient rien ou est nul
                    compteur = 1; //on reinitialise le compteur et old
                    old = null;
                }
                if(compteur == 4){ //Si le compteur vaut 4, il y a victoire. On sort de la boucle
                    quatre = true;
                    break boucle;
                }
            }
        }
        return quatre;
    }

    /**
     * Methode permettant de detecter un alignement de quatre Jetons en diagonale (de haut-gauche vers bas-droit)
     * @return true si quatre Jetons sont alignes en diagonale tel qu'il est dit dans la description
     */
    public boolean quatreDiagonalD() {
        boolean quatre = false; //booleen indiquant l'alignement
        int j; //var d'incrementation de la hauteur
        int debut = 0; //var servant a decaler "i" vers la droite a chaque iteration
        int compteur; //compteur de Jetons alignes
        Jeton old; //Jeton que l'on compte
        boucle: //label servant a stopper l'iteration si quatre memes Jetons sont alignes
        while(debut+3 < largeur-1){ //Tant qu'un aligement de quatre Jetons en diagonal est possible...
            j = 0; //on remet a zero entre chaque tour
            compteur = 1;
            old = null;
            for (int i = 0; i < largeur; i++) { // Boucle sur la largeur
                if (j >= this.getHauteur() || i+debut >= largeur) { //On sort de la premiere boucle si j depasse de la Grille
                    break;
                }
                try {
                    if (!this.listeColonnes.get(i+debut).tabValDansOrdre(this.getHauteur())[j].equals(old)) { //Si le Jeton vise est different du old...
                        old = this.listeColonnes.get(i+debut).tabValDansOrdre(this.getHauteur())[j]; //on assigne a old le Jeton vise et on reinitialise le compteur
                        compteur = 1;
                        j++; //on incremente la variable contenant la hauteur
                    } else { //sinon on incremente le compteur et la hauteur
                        compteur++;
                        j++;
                    }
                } catch (ArrayIndexOutOfBoundsException | NullPointerException e) { //Exception dans le cas où l'element vise ne contient rien ou est nul
                    compteur = 1; //on reinitialise le compteur, old et on incremente la hauteur
                    old = null;
                    j++;
                }
                if (compteur == 4) { //Si le compteur vaut 4, il y a victoire. On sort de la boucle
                    quatre = true;
                    break boucle;
                }
            }
            debut++; // on incremente debut, variable qui sert a decaler "i"
        }

        if(!quatre) { //On verifie la zone "morte" pas fouillée, avec un autre type de boucle qui incremente vers le haut, si aucune diagonale n'a ete trouvee jusqu'ici
            int k = 1; //Le cas où la hauteur est de 0 est deja verifie
            boucle:
            while (k + 3 < this.getHauteur()) { //Tant qu'une diagonale de 4 Jetons est toujours possible
                j = k;
                compteur = 1;
                old = null;
                for (int i = 0; i < largeur; i++) {
                    try {
                        if (!this.listeColonnes.get(i).tabValDansOrdre(this.getHauteur())[j].equals(old)) { //Si le Jeton vise est different du old...
                            old = this.listeColonnes.get(i).tabValDansOrdre(this.getHauteur())[j]; //on assigne a old le Jeton vise et on reinitialise le compteur
                            compteur = 1;
                        } else { //sinon on incremente le compteur et la hauteur
                            compteur++;
                        }
                    } catch (ArrayIndexOutOfBoundsException | NullPointerException e) { //Exception dans le cas où l'element vise ne contient rien ou est nul
                        compteur = 1; //on reinitialise le compteur, old et on incremente la hauteur
                        old = null;
                    }

                    if (compteur == 4) { //Si le compteur vaut 4, il y a victoire. On sort de la boucle
                        quatre = true;
                        break boucle;
                    }
                    j++;
                }
                k++;
            }
        }
        return quatre;
    }

    /**
     * Methode permettant de detecter un alignement de quatre Jetons en diagonale (de haut-gauche vers bas-droit)
     * @return true si quatre Jetons sont alignes en diagonale tel qu'il est dit dans la description
     */
    public boolean quatreDiagonalG() {
        boolean quatre = false; //booleen indiquant l'alignement
        int j; //var d'incrementation de la hauteur
        int debut = 0; //var servant a decaler "i" vers la droite a chaque iteration
        int compteur; //compteur de Jetons alignes
        Jeton old; //Jeton que l'on compte
        boucle: //label servant a stopper l'iteration si quatre memes Jetons sont alignes
        while(debut+3 < largeur-1){//Tant qu'un aligement de quatre Jetons en diagonal est possible...
            j = 0; //on remet a zero entre chaque tour
            compteur = 1;
            old = null;
            for (int i = largeur-1; i >= 0; i--) { // Boucle sur la largeur
                if (j >= this.getHauteur() || i-debut < 0) { //On sort de la premiere boucle si j depasse de la Grille
                    break;
                }
                try {
                    if (!this.listeColonnes.get(i-debut).tabValDansOrdre(this.getHauteur())[j].equals(old)) { //Si le Jeton vise est different du old...
                        old = this.listeColonnes.get(i-debut).tabValDansOrdre(this.getHauteur())[j]; //on assigne a old le Jeton vise et on reinitialise le compteur
                        compteur = 1;
                        j++; //on incremente la variable contenant la hauteur
                    } else { //sinon on incremente le compteur et la hauteur
                        compteur++;
                        j++;
                    }
                } catch (ArrayIndexOutOfBoundsException | NullPointerException e) { //Exception dans le cas où l'element vise ne contient rien ou est nul
                    compteur = 1; //on reinitialise le compteur, old et on incremente la hauteur
                    old = null;
                    j++;
                }
                if (compteur == 4) { //Si le compteur vaut 4, il y a victoire. On sort de la boucle
                    quatre = true;
                    break boucle;
                }
            }
            debut++; // on incremente debut, variable qui sert a decaler "i"
        }

        if(!quatre){ //On verifie la zone "morte" pas fouillée, avec un autre type de boucle qui incremente vers le haut, si aucune diagonale n'a ete trouvee jusqu'ici
            int k = 1; //Le cas où la hauteur est de 0 est deja verifie
            boucle:
            while(k+3 < this.getHauteur()){ //Tant qu'une diagonale de 4 Jetons est toujours possible
                j = k;
                compteur = 1;
                old = null;
                for(int i = largeur-1; i >= 0; i--){
                    try {
                        if (!this.listeColonnes.get(i).tabValDansOrdre(this.getHauteur())[j].equals(old)) { //Si le Jeton vise est different du old...
                            old = this.listeColonnes.get(i).tabValDansOrdre(this.getHauteur())[j]; //on assigne a old le Jeton vise et on reinitialise le compteur
                            compteur = 1;
                        } else { //sinon on incremente le compteur et la hauteur
                            compteur++;
                        }
                    } catch (ArrayIndexOutOfBoundsException | NullPointerException e) { //Exception dans le cas où l'element vise ne contient rien ou est nul
                        compteur = 1; //on reinitialise le compteur, old et on incremente la hauteur
                        old = null;
                    }

                    if (compteur == 4) { //Si le compteur vaut 4, il y a victoire. On sort de la boucle
                        quatre = true;
                        break boucle;
                    }
                    j++;
                }
                k++;
            }
        }
        return quatre;
    }

    /**
     * Methode permettant de verifier si la Grille presente une situation de victoire,
     * c-a-d si 4 memes Jetons sont alignes. Si c'est le cas, la methode renvoie la valeur du Jeton gagnant
     * @return true si 4 memes Jetons sont alignes
     */
    public boolean victoire(){
        return (quatreVertical() || quatreHorizontal() || quatreDiagonalD() || quatreDiagonalG());
    }

    /**
     * Methode d'affichage de la Grille
     * @return Un affichage de la Grille
     */
    public String toString() {
        StringBuilder grille = new StringBuilder(); //On utilise ici StringBuilder pour faciliter les operation sur les String
        grille.append("+").append("-+".repeat(largeur)).append("\n"); // Ligne composee de + et de -
        String val;
        for (int i = 0; i < hauteur; i++) { //Boucle operant sur chaque ligne de la Grille
            grille.append("|");
            for(int j = 0; j<largeur; j++) { //Boucle operant sur chaque Colonne de la Grille
                try {
                    val = String.valueOf(this.listeColonnes.get(j).tabVal(this.getHauteur())[i].getValeur());
                    if(val != null) grille.append(val).append("|");
                    else grille.append(" ").append("|");
                } catch(NullPointerException e){ // Null est dans les cases du tableau de Colonne sans valeur
                    grille.append(" ").append("|"); // On remplace donc cela par un espace
                }
            }
            grille.append("\n");
            grille.append("+").append("-+".repeat(largeur)).append("\n"); // Ligne composee de + et de -
        }

        for(int i = 0; i<largeur; i++){ // Boucle permettant d'afficher les numeros des Colonnes sous la Grille
            grille.append(" ").append(i);
        }
        grille.append("\n");

        return grille.toString();

    }

}


