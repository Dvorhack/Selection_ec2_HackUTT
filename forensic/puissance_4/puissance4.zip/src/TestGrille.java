public class TestGrille {
    public static void main(String[] args) {

        try {
            VraiJoueur j1 = new VraiJoueur(new Jeton(1), "joueur 1");
            VraiJoueur j2 = new VraiJoueur(new Jeton(2), "joueur 1");

            //Test d'insertion de grille + affichage
            Grille g = new Grille();
            g.inserer(j1, 3);
            System.out.println("\nTest 1 : ");
            System.out.println(g.toString());

            //Test plusieurs insertions
            g.inserer(j1, 3);
            g.inserer(j1, 3);
            g.inserer(j1, 5);
            g.inserer(j2, 4);
            System.out.println("\nTest 2 : ");
            System.out.println(g.toString());

            //Test suppression de Jeton grace à l'historique (doit afficher la Colonne 4 vide)
            g.restaurerHistorique();
            System.out.println("\nTest 3 : ");
            System.out.println(g);

            //Test de sauvegarde et restauration
            System.out.println("\nTest 4 : ");
            g.sauvegarder();
            g.inserer(j2, 4);
            g = Grille.restaurer();
            System.out.println(g);

            //Test de l'affichage de la Grille amélioré (remplissage etc.)
            System.out.println("\nTest 5 : ");
            System.out.println(g.affichageRemplissageTrie());

            //Test de victoire
            System.out.println("\nTest 6 : ");
            g.inserer(j1, 3);
            System.out.println(g.victoire()); //vertical (true)

            g.restaurerHistorique();
            g.inserer(j1, 4);
            g.inserer(j1, 6);
            System.out.println(g.victoire()); //horizontal (true)

            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.inserer(j1, 2);
            g.inserer(j2, 4);
            g.inserer(j2, 4);
            g.inserer(j2, 5);
            g.inserer(j2, 5);
            g.inserer(j2, 5);
            g.inserer(j1, 5);
            g.inserer(j1, 4);
            System.out.println(g.victoire()); //diagonale droite (true)

            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.restaurerHistorique();
            g.inserer(j1, 4);
            g.inserer(j1, 4);
            g.inserer(j1, 5);
            g.inserer(j2, 5);
            g.inserer(j2, 6);
            g.inserer(j2, 4);
            g.inserer(j2, 3);
            System.out.println(g.victoire()); //diagonale gauche (true)




        } catch (JetonException e) {
            e.printStackTrace();
        }

    }
}
