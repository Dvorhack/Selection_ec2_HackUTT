import java.util.Scanner;

public class VraiJoueur extends Joueur{

    /** Nom du joueur */
    private String nom;

    /**
     * Constructeur de VraiJoueur
     * @param j jeton associe au joueur
     * @param s nom associe au joueur
     */
    public VraiJoueur(Jeton j, String s) {
        super(j);
        this.nom = s;
    }

    /**
     * Methode permettant de demander quel choix le Joueur souhaite effectuer
     * @return choix effectue par le Joueur
     * @exception NumberFormatException renvoyee si le Joueur entre autre chose qu'un chiffre dans l'input
     */
    public int demanderChoix() throws NumberFormatException{
        Scanner sc = new Scanner(System.in);
        System.out.println("[+] Veuillez entrer un chiffre pour choisir une option : ");
        System.out.println("    (0) Annuler la dernière insertion");
        System.out.println("    (1) Jouer");
        System.out.println("    (2) Charger la partie sauvegardée");
        System.out.println("    (3) Sauvegarder la partie");
        System.out.println("    (4) Quitter la partie");
        System.out.println("    (5) Demander un conseil au grand sage...");


        String choixStr = sc.nextLine();
        int choix = Integer.parseInt(choixStr);
        while (choix != 0 && choix != 1 && choix != 2 && choix != 3 && choix != 4 && choix != 5) {
            System.out.println("Choix invalide...");
            choixStr = sc.nextLine();
            choix = Integer.parseInt(choixStr);
        }
        return choix;
    }

    /**
     * Methode permettant de demander quelle Colonne le Joueur souhaite choisir pour placer son Jeton
     * @return choix effectue par le Joueur
     */
    public int demanderColonne(){
        Scanner sc = new Scanner(System.in);
        System.out.println("[+] Veuillez entrer un numero de Colonne : ");
        int choix = sc.nextInt();
        while(choix < 0 || choix > Grille.largeur){
            System.out.println("Choix invalide...");
            System.out.println("[+] Veuillez entrer un numero de Colonne : ");
            choix = sc.nextInt();
        }
        return choix;
    }

    /**
     * Methode get du nom du Joueur
     * @return nom du Joueur
     */
    public String getNom() { return nom; }

    /**
     * Methode toString de la classe VraiJoueur
     * @return l'Affichage du VraiJoueur
     */
    public String toString() {
        String res = "Joueur : " + this.getNom();
        return res;
    }
}
