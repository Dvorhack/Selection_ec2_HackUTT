import java.io.Serializable;
import java.util.LinkedList;

// Classe Pile
public class Pile implements Serializable {

    /** Liste doublement chainee representant une pile (structure FIFO) d'entiers */
    private LinkedList<Integer> pile;

    /**
     * Contructeur de pile
     */
    public Pile(){
        this.pile = new LinkedList<Integer>();
    }

    /**
     * Methode d'empilement d'un entier
     * @param e entier a empiler
     */
    public void empiler(int e){
        this.pile.add(e);
    }

    /**
     * Methode de depilement d'un entier
     * @return le dernier element
     */
    public int depiler(){
        return this.pile.removeLast();
    }
}
