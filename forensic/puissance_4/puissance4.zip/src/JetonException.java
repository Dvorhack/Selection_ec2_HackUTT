public class JetonException extends Exception {

    public JetonException(){
        super();
    }

    public JetonException(String msg){
        super(msg);
    }
}
