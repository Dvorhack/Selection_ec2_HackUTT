import java.util.*;


public class Main {

    public static Joueur[] menuPrincipal() throws InterruptedException, JetonException, NumberFormatException {
        for(int i = 0; i<50; i++){ //On passe beaucoup de lignes pour "changer de fenetre"
            System.out.println("\n");
        }

        Scanner sc = new Scanner(System.in);

        System.out.println("[+] Veuillez entrer le nombre de joueurs (>0): ");
        String nbJoueursStr = sc.nextLine();
        int nbJoueurs = Integer.parseInt(nbJoueursStr);
        while(nbJoueurs <= 1){
            if(nbJoueurs == 1) System.out.println("Tu veux vraiment jouer tout seul ? Tu dois sérieusement t'ennuyer pendant le confinement... je ne peux pas te laisser faire ca\n");
            nbJoueursStr = sc.nextLine();
            nbJoueurs = Integer.parseInt(nbJoueursStr);
        }

        System.out.println("[+] Il y aura "+ nbJoueurs +" joueurs !");
        Joueur[] joueurs = new Joueur[nbJoueurs];
        Thread.sleep(1000);

        System.out.println("[+] Souhaitez-vous inclure des Bots dans la partie ? (Entrer 0 si vous ne voulez pas ): ");
        String nbBotsStr = sc.nextLine();
        int nbBots = Integer.parseInt(nbBotsStr);
        while(nbBots > nbJoueurs || nbBots < 0){
            nbBotsStr = sc.nextLine();
            nbBots = Integer.parseInt(nbBotsStr);
        }
        boolean queDesBots = (nbBots == nbJoueurs);
        for(int i = 0; i<nbBots; i++) {
            joueurs[i] = new Bot(new Jeton(i));
        }

        if(!queDesBots){
            System.out.println("[+] Passons aux joueurs ! ");
            Thread.sleep(1000);
            System.out.println("[+] Entrez vos noms successivement");

            for(int i = nbBots; i<nbJoueurs; i++){
                System.out.println("Nom : ");
                String nom = sc.nextLine();
                joueurs[i] = new VraiJoueur(new Jeton(i), nom);
            }
        } else
            System.out.println("[+] Vous devez vous ennuyer pour vouloir regarder des bots se battre sur un Puissance4...");

        Thread.sleep(1000);

        System.out.println("[+] Voici la liste des joueurs de la partie : "); //On affiche les Joueurs

        for(int i = 0; i<nbJoueurs; i++){
            System.out.println(joueurs[i].toString());
        }

        Thread.sleep(2000); //On simule un chargement pour rendre plus fluide l'execution

        System.out.println("[+] Veuillez entrer la largeur de la Grille (comprise entre 4 et 10) : "); //4 et 10 pour permettre une bonne jouabilité
        String largeurStr = sc.nextLine();
        int largeur = Integer.parseInt(largeurStr);
        while(largeur < 4 || largeur > 10){
            largeurStr = sc.nextLine();
            largeur = Integer.parseInt(largeurStr);
        }

        Grille.largeur = largeur;

        for(int i = 0; i<50; i++){ //On passe beaucoup de lignes pour "changer de fenetre"
            System.out.println("\n");
        }

        //Je ne ferme pas le Scanner car cela provoque une erreur dans l'execution

        return joueurs;
    }

    public static void main(String[] args) {
        try {

            //Ecran de demarrage
            System.out.println("----------------------");
            System.out.println("Jeu du Puissance 4");
            System.out.println("Yanis TALEB S2A");
            System.out.println("DUT Informatique 1A");
            System.out.println("----------------------");
            Thread.sleep(2000); //On attend 1sec



            jeu:
            while(true){
                Joueur[] joueurs = menuPrincipal();

                Jeu j = new Jeu(joueurs);

                memesJoueurs:
                while(true){

                    for(int i = 0; i<joueurs.length; i++){
                        int c = j.jouer(i);
                        if(c == 4) break jeu;
                        if(c == 0 || c == 2 || c == 3 || c == 5) i--;
                        if(c == 10){
                            for(int k = 0; k<50; k++){ //On passe beaucoup de lignes pour "changer de fenetre"
                                System.out.println("\n");
                            }
                            System.out.println("[+] Souhaitez vous rejouer ?");
                            System.out.println("    (0) Quitter");
                            System.out.println("    (1) Rejouer avec les memes joueurs");
                            System.out.println("    (2) Rejouer");
                            Scanner sc = new Scanner(System.in);
                            String choixStr = sc.nextLine();
                            int choix = Integer.parseInt(choixStr);
                            while(choix != 0 && choix != 1 && choix != 2){
                                choixStr = sc.nextLine();
                                choix = Integer.parseInt(choixStr);
                            }
                            if(choix == 0) break jeu;
                            else if(choix == 2) break memesJoueurs;
                            else{
                                j = new Jeu(joueurs);
                            }
                            break;
                        }
                    }

                }

            }

            System.out.println("[+] Arret du jeu...");


        } catch (JetonException e){
            System.out.println(e);
            System.exit(-1); // Sortie du programme
        } catch (InterruptedException e){
            System.out.println("[+] Interruption du programme");
            System.exit(-1);
        } catch (NumberFormatException e){
            System.out.println("[+] Il vous était demandé d'entrer un numéro... pas autre chose");
            System.out.println("[+] Interruption du programme");
            System.exit(-1);
        }





    }
}
