public class TestJoueur {

    public static void main(String[] args) throws JetonException {

        //Test de création d'un VraiJoueur (doit afficher Yanis)
        System.out.println("\nTest 1 : ");
        VraiJoueur vj = new VraiJoueur(new Jeton(1), "Yanis");
        System.out.println(vj.getNom());

        //Test d'affichage du Jeton d'un Joueur (doit afficher 1)
        System.out.println("\nTest 2 : ");
        System.out.println(vj.getJeton().getValeur());

        //Test de d'affichage d'un joueur (doit afficher Joueur : Yanis)
        System.out.println("\nTest 3 : ");
        System.out.println(vj.toString());

        //Test de demande de choix d'un VJ (doit demander le choix à faire)
        System.out.println("\nTest 4 : ");
        vj.demanderChoix();

        //Test de demande de colonne d'un VJ (doit demander le choix à faire)
        System.out.println("\nTest 5 : ");
        vj.demanderColonne();

        //--------------------//

        //Test de creation d'un bot + affichage du bot (doit afficher Bot : <nom>)
        System.out.println("\n\n\nTest 1 : ");
        Bot b = new Bot(new Jeton(2));
        System.out.println(b.toString());

        //Test d'augmentation de la victoire des deux joueurs (doit afficher 2-2)
        b.augmenterVictoire();
        b.augmenterVictoire();
        vj.augmenterVictoire();
        vj.augmenterVictoire();
        System.out.println(b.getVictoire() + "-" + vj.getVictoire());

    }

}
